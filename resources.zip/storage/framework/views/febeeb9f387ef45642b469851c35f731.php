<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($title ?? 'Admin Panel'); ?> — Helvetica POS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(class_exists(\Livewire\Livewire::class)): ?> <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</head>
<body class="min-h-screen bg-[#f7f9fb] text-slate-900 antialiased">
    <div class="min-h-screen lg:flex">
        <aside class="w-full border-b border-slate-200 bg-white lg:min-h-screen lg:w-72 lg:border-b-0 lg:border-r">
            <div class="flex items-center justify-between border-b border-slate-100 px-6 py-6">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex items-center gap-3 text-lg font-black tracking-tight"><span class="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-600 text-sm text-white">H</span><span>Helvetica <span class="text-emerald-600">POS</span></span></a>
            </div>
            <?php $pendingCancellations = \App\Models\OrderCancellationRequest::query()->pending()->count(); ?>
            <div class="px-5 py-6"><p class="px-3 text-[11px] font-bold uppercase tracking-[0.18em] text-slate-400">Workspace</p>
                <nav class="mt-3 space-y-1">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [
                        ['admin.dashboard', 'Dashboard'], ['admin.products.index', 'Produk & harga'], ['admin.categories.index', 'Kategori'], ['admin.expenses.index', 'Expenses'], ['admin.sales-report', 'Laporan'], ['admin.cancellations.index', 'Pembatalan'], ['admin.shifts.index', 'Cash monitoring'], ['admin.users.index', 'Staff'], ['pos.index', 'Buka POS'],
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$route, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <a href="<?php echo e(route($route)); ?>" class="flex items-center justify-between rounded-xl px-3 py-3 text-sm font-semibold transition <?php echo e(request()->routeIs($route) ? 'bg-emerald-50 text-emerald-700' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'); ?>"><span><?php echo e($label); ?></span><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($route === 'admin.cancellations.index' && $pendingCancellations > 0): ?><span class="rounded-full bg-red-500 px-2 py-0.5 text-[11px] font-bold text-white"><?php echo e($pendingCancellations); ?></span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></a>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </nav>
            </div>
            <div class="hidden border-t border-slate-100 p-5 lg:block"><p class="px-3 text-xs text-slate-400">Sesi admin aktif</p><form class="mt-3" method="POST" action="<?php echo e(route('pos.logout')); ?>"><?php echo csrf_field(); ?><button class="w-full rounded-xl px-3 py-2.5 text-left text-sm font-semibold text-slate-500 hover:bg-red-50 hover:text-red-600">Keluar dari panel</button></form></div>
        </aside>
        <main class="min-w-0 flex-1"><div class="mx-auto max-w-[1440px] p-5 sm:p-8 lg:p-10"><?php echo e($slot); ?></div></main>
    </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(class_exists(\Livewire\Livewire::class)): ?> <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</body>
</html>
<?php /**PATH D:\laragon\www\Helvetica_Engine\resources\views/components/admin-layout.blade.php ENDPATH**/ ?>