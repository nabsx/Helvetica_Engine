<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Laporan Penjualan']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Laporan Penjualan']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="mb-6">
        <p class="text-sm font-semibold text-emerald-600">Analitik penjualan</p>
        <h1 class="mt-1 text-3xl font-black tracking-tight">Laporan penjualan</h1>
        <p class="mt-2 text-sm text-slate-500">Pantau performa transaksi berdasarkan tanggal dan metode pembayaran.</p>
    </div>

    <main class="space-y-6">
        <form method="GET" action="<?php echo e(route('admin.sales-report')); ?>" class="flex flex-wrap items-end gap-3 rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
            <div>
                <label for="tanggal" class="mb-1 block text-sm font-medium text-slate-600">Tanggal laporan</label>
                <input id="tanggal" name="tanggal" type="date" value="<?php echo e($tanggal); ?>" class="rounded-lg border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-emerald-500 focus:ring-emerald-500">
            </div>
            <button class="rounded-lg bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-emerald-500">Tampilkan</button>
        </form>

        <section class="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <?php
                $cards = [
                    ['label' => 'Total Transaksi', 'value' => number_format($laporan['total_transaksi'], 0, ',', '.')],
                    ['label' => 'Pendapatan Kotor', 'value' => 'Rp '.number_format($laporan['total_pendapatan_kotor'], 0, ',', '.')],
                    ['label' => 'PB1 Terkumpul', 'value' => 'Rp '.number_format($laporan['total_pajak'], 0, ',', '.')],
                    ['label' => 'Pendapatan Bersih / DPP', 'value' => 'Rp '.number_format($laporan['total_pendapatan_bersih'], 0, ',', '.')],
                    ['label' => 'Pembulatan CASH', 'value' => 'Rp '.number_format($laporan['total_uang_pembulatan'], 0, ',', '.')],
                    ['label' => 'Total Expense', 'value' => 'Rp '.number_format($laporan['total_expense'], 0, ',', '.')],
                    ['label' => 'Net Profit', 'value' => 'Rp '.number_format($laporan['net_profit'], 0, ',', '.')],
                ];
            ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <article class="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
                    <p class="text-sm text-slate-500"><?php echo e($card['label']); ?></p>
                    <p class="mt-2 text-xl font-mono tabular-nums font-semibold text-slate-900"><?php echo e($card['value']); ?></p>
                </article>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </section>

        <section class="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 px-5 py-4">
                <h2 class="font-bold">Pendapatan berdasarkan metode pembayaran</h2>
                <p class="mt-1 text-sm text-slate-500">Periode <?php echo e(\Carbon\CarbonImmutable::parse($tanggal)->translatedFormat('d F Y')); ?></p>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full text-left text-sm">
                    <thead class="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                        <tr>
                            <th class="px-5 py-3">Metode</th>
                            <th class="px-5 py-3">Jumlah Transaksi</th>
                            <th class="px-5 py-3">Pendapatan Kotor</th>
                            <th class="px-5 py-3">Total Dibayar</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['CASH', 'QRIS']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <?php $payment = $laporan['breakdown_pembayaran'][$method]; ?>
                            <tr>
                                <td class="px-5 py-4 font-semibold"><?php echo e($method); ?></td>
                                <td class="px-5 py-4"><?php echo e(number_format($payment['jumlah_transaksi'], 0, ',', '.')); ?></td>
                                <td class="px-5 py-4">Rp <?php echo e(number_format($payment['total_pendapatan'], 0, ',', '.')); ?></td>
                                <td class="px-5 py-4 font-semibold">Rp <?php echo e(number_format($payment['total_dibayar'], 0, ',', '.')); ?></td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 px-5 py-4">
                <h2 class="font-bold">Detail transaksi</h2>
                <p class="mt-1 text-sm text-slate-500">Lihat barang yang dibeli berdasarkan nomor order.</p>
            </div>
            <div class="divide-y divide-slate-100">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $laporan['transaksi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <details class="group px-5 py-4">
                        <summary class="flex cursor-pointer list-none items-center justify-between gap-4">
                            <div>
                                <p class="font-semibold"><?php echo e($order->order_number); ?></p>
                                <p class="mt-1 text-xs text-slate-500"><?php echo e(strtoupper($order->payment_type)); ?> · <?php echo e($order->created_at?->timezone('Asia/Jakarta')->format('H:i')); ?></p>
                            </div>
                            <div class="flex items-center gap-4">
                                <span class="font-semibold">Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></span>
                                <span class="text-sm text-emerald-600 group-open:hidden">Lihat detail</span>
                                <span class="hidden text-sm text-slate-500 group-open:inline">Tutup</span>
                            </div>
                        </summary>
                        <div class="mt-4 overflow-x-auto rounded-lg bg-slate-50 p-4">
                            <table class="min-w-full text-left text-sm">
                                <thead class="text-xs uppercase tracking-wide text-slate-500">
                                    <tr><th class="pb-2">Produk</th><th class="pb-2">Qty</th><th class="pb-2">Harga</th><th class="pb-2 text-right">Subtotal</th></tr>
                                </thead>
                                <tbody class="divide-y divide-slate-200">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                        <tr>
                                            <td class="py-2"><?php echo e($item->product_name ?: ($item->product?->name ?? 'Produk')); ?></td>
                                            <td class="py-2"><?php echo e($item->quantity); ?></td>
                                            <td class="py-2">Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?></td>
                                            <td class="py-2 text-right font-medium">Rp <?php echo e(number_format($item->subtotal, 0, ',', '.')); ?></td>
                                        </tr>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </tbody>
                            </table>
                            <div class="mt-3 flex justify-end border-t border-slate-200 pt-3 text-sm font-bold">TOTAL&nbsp; Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></div>
                        </div>
                    </details>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <p class="px-5 py-8 text-center text-sm text-slate-500">Tidak ada transaksi pada tanggal ini.</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </section>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\Helvetica_Engine\resources\views/admin/sales-report.blade.php ENDPATH**/ ?>