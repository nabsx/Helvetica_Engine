<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Pembatalan Transaksi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Pembatalan Transaksi']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <div class="mb-6">
        <p class="text-sm font-semibold text-emerald-600">Kontrol kasir</p>
        <h1 class="mt-1 text-3xl font-black tracking-tight">Pengajuan pembatalan transaksi</h1>
        <p class="mt-2 text-sm text-slate-500">Kasir hanya bisa mengajukan — transaksi baru benar-benar batal setelah Anda menyetujui di sini.</p>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?><div class="mb-6 rounded-xl bg-emerald-50 px-4 py-3 text-sm text-emerald-700"><?php echo e(session('success')); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?><div class="mb-6 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700"><?php echo e(session('error')); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <main class="space-y-8">
        
        <section class="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 px-5 py-4">
                <h2 class="font-bold">Menunggu persetujuan</h2>
                <p class="mt-1 text-sm text-slate-500"><?php echo e($pending->count()); ?> pengajuan belum diproses.</p>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="border-b border-slate-100 px-5 py-5 last:border-b-0">
                    <div class="flex flex-wrap items-start justify-between gap-4">
                        <div class="min-w-0">
                            <div class="flex items-center gap-2">
                                <p class="font-bold"><?php echo e($request->order->order_number); ?></p>
                                <span class="rounded-full bg-amber-50 px-2 py-0.5 text-xs font-bold text-amber-700">Pending</span>
                            </div>
                            <p class="mt-1 text-sm text-slate-500">
                                Rp <?php echo e(number_format($request->order->total_amount, 0, ',', '.')); ?> ·
                                diajukan oleh <?php echo e($request->requestedBy->name); ?> ·
                                <?php echo e($request->created_at->diffForHumans()); ?>

                            </p>
                            <p class="mt-2 rounded-lg bg-slate-50 px-3 py-2 text-sm text-slate-700">"<?php echo e($request->reason); ?>"</p>
                        </div>

                        <div class="flex shrink-0 flex-col gap-2 sm:flex-row">
                            <form method="POST" action="<?php echo e(route('admin.cancellations.reject', $request)); ?>"
                                  onsubmit="return confirm('Tolak pengajuan pembatalan ini? Transaksi tetap berstatus paid.')">
                                <?php echo csrf_field(); ?>
                                <button class="w-full rounded-lg bg-slate-100 px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-200 sm:w-auto">
                                    Tolak
                                </button>
                            </form>
                            <form method="POST" action="<?php echo e(route('admin.cancellations.approve', $request)); ?>"
                                  onsubmit="return confirm('Setujui pembatalan <?php echo e($request->order->order_number); ?>? Stok produk akan dikembalikan otomatis.')">
                                <?php echo csrf_field(); ?>
                                <button class="w-full rounded-lg bg-red-600 px-4 py-2 text-sm font-bold text-white hover:bg-red-500 sm:w-auto">
                                    Setujui &amp; Batalkan
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <p class="px-5 py-8 text-center text-sm text-slate-400">Tidak ada pengajuan yang menunggu.</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </section>

        
        <section class="rounded-xl border border-slate-200 bg-white shadow-sm">
            <div class="border-b border-slate-200 px-5 py-4">
                <h2 class="font-bold">Riwayat keputusan</h2>
                <p class="mt-1 text-sm text-slate-500">30 pengajuan terakhir yang sudah diproses.</p>
            </div>
            <div class="overflow-x-auto">
                <table class="min-w-full text-left text-sm">
                    <thead class="bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
                        <tr>
                            <th class="px-5 py-3">Order</th>
                            <th class="px-5 py-3">Diajukan Oleh</th>
                            <th class="px-5 py-3">Keputusan</th>
                            <th class="px-5 py-3">Ditinjau Oleh</th>
                            <th class="px-5 py-3">Catatan Admin</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $resolved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr>
                                <td class="px-5 py-4 font-semibold"><?php echo e($request->order->order_number); ?></td>
                                <td class="px-5 py-4"><?php echo e($request->requestedBy->name); ?></td>
                                <td class="px-5 py-4">
                                    <span class="rounded-full px-2 py-0.5 text-xs font-bold <?php echo e($request->status === 'approved' ? 'bg-red-50 text-red-700' : 'bg-slate-100 text-slate-600'); ?>">
                                        <?php echo e($request->status === 'approved' ? 'Disetujui (Batal)' : 'Ditolak'); ?>

                                    </span>
                                </td>
                                <td class="px-5 py-4"><?php echo e($request->reviewedBy?->name ?? '—'); ?></td>
                                <td class="px-5 py-4 text-slate-500"><?php echo e($request->admin_note ?: '—'); ?></td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr><td colspan="5" class="px-5 py-8 text-center text-slate-400">Belum ada riwayat.</td></tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\Helvetica_Engine\resources\views/admin/cancellations/index.blade.php ENDPATH**/ ?>