<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($receipt['order']['number']); ?></title>
    <style>
        @page { size: 58mm auto; margin: 0; }
        * { box-sizing: border-box; }
        body { width: 58mm; margin: 0 auto; padding: 3mm; color: #111; background: #fff; font: 11px/1.35 "Courier New", monospace; }
        .center { text-align: center; }
        .row { display: flex; justify-content: space-between; gap: 8px; font-family: "JetBrains Mono", "Courier New", monospace; font-variant-numeric: tabular-nums; }
        .item-name { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .muted { color: #555; }
        hr { border: 0; border-top: 1px dashed #111; margin: 7px 0; }
        h1 { font-size: 14px; margin: 0; }
        .total { font-weight: 700; font-size: 13px; }
        @media screen { body { margin-top: 16px; box-shadow: 0 0 12px #bbb; } }
    </style>
</head>
<body>
    <header class="center">
        <h1><?php echo e($receipt['store']['name']); ?></h1>
        <div><?php echo e($receipt['store']['address']); ?></div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($receipt['store']['phone']): ?> <div><?php echo e($receipt['store']['phone']); ?></div> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </header>

    <hr>
    <div><?php echo e($receipt['order']['number']); ?></div>
    <div class="muted"><?php echo e($receipt['order']['date']); ?> · <?php echo e($receipt['order']['cashier']); ?></div>
    <div class="muted">Pembayaran: <?php echo e($receipt['order']['payment_type']); ?></div>
    <hr>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $receipt['order']['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <div class="item-name"><?php echo e($item['name']); ?></div>
        <div class="row">
            <span><?php echo e($item['quantity']); ?> x <?php echo e(number_format($item['price'], 0, ',', '.')); ?></span>
            <span><?php echo e(number_format($item['subtotal'], 0, ',', '.')); ?></span>
        </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

    <hr>
    <div class="row"><span>Total Belanja</span><span><?php echo e(number_format($receipt['order']['subtotal'], 0, ',', '.')); ?></span></div>
    <div class="row"><span>DPP</span><span><?php echo e(number_format($receipt['order']['dpp'], 0, ',', '.')); ?></span></div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $receipt['order']['tax_summary']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <div class="row"><span><?php echo e($tax['label']); ?></span><span><?php echo e($tax['tax_amount'] === null ? '-' : number_format($tax['tax_amount'], 0, ',', '.')); ?></span></div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
    <div class="row"><span>Pembulatan</span><span><?php echo e(number_format($receipt['order']['rounding_adjustment'], 0, ',', '.')); ?></span></div>
    <div class="row total"><span>TOTAL</span><span><?php echo e(number_format($receipt['order']['total_amount'], 0, ',', '.')); ?></span></div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($receipt['order']['cash_given'] !== null): ?>
        <div class="row"><span>Tunai</span><span><?php echo e(number_format($receipt['order']['cash_given'], 0, ',', '.')); ?></span></div>
        <div class="row"><span>Kembalian</span><span><?php echo e(number_format($receipt['order']['change_amount'] ?? 0, 0, ',', '.')); ?></span></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <p class="center">Terima kasih</p>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($autoPrint): ?>
        <script>window.addEventListener('load', () => window.print());</script>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</body>
</html>
<?php /**PATH D:\laragon\www\Helvetica_Engine\resources\views/receipts/thermal.blade.php ENDPATH**/ ?>