
<div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mt-8">
    <div class="lg:col-span-8">
        <section class="bg-amber-50/30 rounded-xl border border-amber-200/80 p-6 shadow-sm">
            <div class="flex items-center justify-between pb-4 mb-4 border-b border-amber-100">
                <div>
                    <span class="text-[11px] font-bold tracking-wider text-amber-700 uppercase">Stock Adjustment</span>
                    <h2 class="text-lg font-bold text-slate-900">Sesuaikan Stok</h2>
                </div>
                <span class="text-xs bg-amber-100/70 text-amber-800 px-2 py-0.5 rounded font-medium">Audit Trail</span>
            </div>
            <p class="text-xs text-slate-600 mb-5 leading-relaxed">
                Untuk koreksi setelah stock opname atau perbaikan salah input. Setiap perubahan tercatat secara permanen di riwayat sebelah kanan — bukan sekadar menimpa angka lama.
            </p>
            <form method="POST" action="<?php echo e(route('admin.products.stock.adjust', $product)); ?>" class="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="sm:col-span-3">
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5" for="new_stock">
                        Stok Baru
                    </label>
                    <input type="number" id="new_stock" name="new_stock" min="0" value="<?php echo e($product->stock); ?>" required
                        class="w-full rounded-lg border-slate-200 text-sm font-bold text-slate-900 focus:border-amber-500 focus:ring-amber-500 bg-white py-2 px-3 shadow-sm">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['new_stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1.5 text-xs text-rose-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="sm:col-span-6">
                    <label class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5" for="note">
                        Alasan Penyesuaian
                    </label>
                    <input type="text" id="note" name="note" placeholder="mis. Stock opname 05/09, barang rusak, restock" required
                        class="w-full rounded-lg border-slate-200 text-sm text-slate-800 focus:border-amber-500 focus:ring-amber-500 bg-white py-2 px-3 shadow-sm">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1.5 text-xs text-rose-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
                <div class="sm:col-span-3">
                    <button type="submit" class="w-full inline-flex items-center justify-center px-4 py-2 text-sm font-semibold text-white bg-amber-600 hover:bg-amber-700 active:bg-amber-800 rounded-lg shadow-sm transition-colors">
                        Simpan
                    </button>
                </div>
            </form>
        </section>
    </div>
</div><?php /**PATH D:\laragon\www\Helvetica_Engine\resources\views/admin/products/stock-adjustment.blade.php ENDPATH**/ ?>