<?php

use App\Http\Controllers\AdminCancellationController;
use App\Http\Controllers\AdminCategoryController;
use App\Http\Controllers\AdminDashboardController;
use App\Http\Controllers\AdminExpenseController;
use App\Http\Controllers\AdminProductController;
use App\Http\Controllers\AdminUserController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CashMonitoringController;
use App\Http\Controllers\OrderCancellationController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PosController;
use App\Http\Controllers\ReceiptController;
use App\Http\Controllers\ShiftController;
use App\Http\Controllers\SalesReportController;
use Illuminate\Support\Facades\Route;

// --- Public: staff login (name picker + PIN pad) ---
Route::get('/login', [AuthController::class, 'showLogin'])->name('pos.login');
Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:5,1')->name('pos.login.submit');

// --- Authenticated staff area ---
Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('pos.logout');

    Route::get('/pos', [PosController::class, 'index'])->name('pos.index');

    Route::middleware('admin')->prefix('admin')->name('admin.')->group(function (): void {
        Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');
        Route::get('/cash-monitoring', [CashMonitoringController::class, 'index'])->name('shifts.index');
        Route::get('/shifts/{shift}', [CashMonitoringController::class, 'show'])->name('shifts.show');
        Route::post('/shifts/{shift}/approve', [CashMonitoringController::class, 'approve'])->name('shifts.approve');
        Route::get('/laporan-penjualan', [SalesReportController::class, 'index'])->name('sales-report');
        Route::get('/expenses', [AdminExpenseController::class, 'index'])->name('expenses.index');
        Route::redirect('/reports', '/admin/dashboard');
        Route::resource('products', AdminProductController::class)->except(['show']);
        Route::patch('/products/{product}/stock', [AdminProductController::class, 'adjustStock'])->name('products.stock.adjust');
        Route::resource('categories', AdminCategoryController::class)->only(['index', 'store', 'update', 'destroy']);
        Route::post('/categories/reorder', [AdminCategoryController::class, 'reorder'])->name('categories.reorder');
        Route::patch('/categories/{category}/toggle', [AdminCategoryController::class, 'toggleActive'])->name('categories.toggle');
        Route::get('/users', [AdminUserController::class, 'index'])->name('users.index');
        Route::post('/users', [AdminUserController::class, 'store'])->name('users.store');
        Route::put('/users/{user}', [AdminUserController::class, 'update'])->name('users.update');
        Route::patch('/users/{user}/reset-pin', [AdminUserController::class, 'resetPin'])->name('users.reset-pin');
        Route::patch('/users/{user}/activate', [AdminUserController::class, 'activate'])->name('users.activate');
        Route::patch('/users/{user}/deactivate', [AdminUserController::class, 'deactivate'])->name('users.deactivate');
        Route::delete('/users/{user}', [AdminUserController::class, 'destroy'])->name('users.destroy');

        // Cancellation approval queue — approving is the ONLY way an
        // order's status becomes 'cancelled'. A cashier's request alone
        // never changes it (see OrderCancellationController::store).
        Route::get('/pembatalan', [AdminCancellationController::class, 'index'])->name('cancellations.index');
        Route::post('/pembatalan/{cancellationRequest}/approve', [AdminCancellationController::class, 'approve'])->name('cancellations.approve');
        Route::post('/pembatalan/{cancellationRequest}/reject', [AdminCancellationController::class, 'reject'])->name('cancellations.reject');
    });

    Route::get('/orders/{order}/receipt', [ReceiptController::class, 'show'])
        ->name('orders.receipt');
    Route::get('/orders/{order}/receipt/escpos', [ReceiptController::class, 'escpos'])
        ->name('orders.receipt.escpos');

    // Cashier-facing: submit a request only, never a direct cancel.
    Route::post('/orders/{order}/cancellation-requests', [OrderCancellationController::class, 'store'])
        ->name('orders.cancellation-requests.store');

    Route::post('/shifts/open', [ShiftController::class, 'open'])->name('shifts.open');
    Route::post('/shifts/close', [ShiftController::class, 'close'])->name('shifts.close');

    // Live cart total preview — same calculation engine as store(), so the
    // number shown to the cashier always matches what gets saved/printed.
    Route::post('/orders/calculate', [OrderController::class, 'calculate'])->name('orders.calculate');

    // Orders additionally require an OPEN shift — enforced server-side.
    Route::middleware('shift.active')->group(function () {
        Route::post('/orders', [OrderController::class, 'store'])->name('orders.store');
    });
});